from django.contrib import admin
from .models import Authors

# Register your models here.
admin.site.register(Authors)
